#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FINAL_PLATINUM_RUS_V30_OLD_UI_SILENT.py
- Дизайн: Старый (Неон/Зеленый)
- Логика: Тихий авто-пароль 0812Danil
- Фиксы: Скрыты ошибки RuntimeWarning
"""

import asyncio
import os
import re
import sys
import time
import random
import subprocess
import shutil
import warnings
from pathlib import Path
from typing import Optional, List, Tuple

# --- ГЛУШИЛКА ПРЕДУПРЕЖДЕНИЙ (Чтобы не мусорило в консоль) ---
warnings.filterwarnings("ignore", category=RuntimeWarning, module="opentele")
warnings.filterwarnings("ignore", message=".*AuthMethods._on_login.*")

# -------------------- БИБЛИОТЕКИ --------------------
try:
    from telethon import TelegramClient
    from telethon.errors import (
        SessionPasswordNeededError, FloodWaitError,
        RPCError
    )
    from telethon.tl.functions.channels import CreateChannelRequest, TogglePreHistoryHiddenRequest
    from telethon.tl.functions.messages import UpdateDialogFilterRequest
    from telethon.tl.functions.folders import EditPeerFoldersRequest
    from telethon.tl.functions.auth import LogOutRequest
    from telethon.tl.types import (
        DialogFilter, InputFolderPeer, TextWithEntities
    )
except ImportError:
    print("❌ Ошибка: Нет библиотеки telethon. Установите: pip install telethon")
    sys.exit(1)

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.align import Align
    from rich import box
    from rich.prompt import Prompt
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeRemainingColumn
except ImportError:
    print("❌ Ошибка: Нет библиотеки rich. Установите: pip install rich")
    sys.exit(1)

# --- ИМПОРТ OPENTELE ---
try:
    from opentele.td import TDesktop
    from opentele.api import API
    from opentele.exception import NoPasswordProvided
    OPENTELE_AVAILABLE = True
except ImportError:
    OPENTELE_AVAILABLE = False
    NoPasswordProvided = Exception 

# -------------------- НАСТРОЙКИ --------------------

DEFAULT_2FA_PASS = "0812Danil"  # ВАШ ПАРОЛЬ

BASE_DIR = Path.cwd()
SESSIONS = BASE_DIR / "sessions"
DATA_DIR = BASE_DIR / "DATA"
PHONES_FILE = BASE_DIR / "phones.txt"
ENV_FILE = BASE_DIR / ".env"

SESSIONS.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)

COOLDOWN = 6
ACCOUNT_COOLDOWN = 1 
ARCHIVE_CHUNK_SIZE = 15 
console = Console()

# -------------------- 🛡️ ПОДКАЧКА (SWAP) --------------------

def enable_swap():
    if os.name == 'nt': return 
    try:
        res = subprocess.run("swapon --show", shell=True, capture_output=True, text=True)
        if res.stdout.strip(): return 
        console.print(" [bold yellow]ℹ[/bold yellow] [dim]Создание SWAP...[/dim]")
        cmds = [
            "fallocate -l 4G /swapfile",
            "chmod 600 /swapfile",
            "mkswap /swapfile",
            "swapon /swapfile",
            "echo '/swapfile none swap sw 0 0' | tee -a /etc/fstab"
        ]
        for cmd in cmds: subprocess.run(cmd, shell=True, capture_output=True)
    except Exception: pass 

# -------------------- ИНТЕРФЕЙС (СТАРЫЙ) --------------------

ASCII_ART = r"""
[bold cyan]
████████╗███████╗██╗     ███████╗███╗   ███╗
╚══██╔══╝██╔════╝██║     ██╔════╝████╗ ████║
   ██║   █████╗  ██║     █████╗  ██╔████╔██║
   ██║   ██╔══╝  ██║     ██╔══╝  ██║╚██╔╝██║
   ██║   ███████╗███████╗███████╗██║ ╚═╝ ██║
   ╚═╝   ╚══════╝╚══════╝╚══════╝╚═╝     ╚═╝
[/bold cyan][bold green]   LOCAL VERSION // V30 SILENT [/bold green]
"""

def clear_screen(): os.system("cls" if os.name == "nt" else "clear")

def fake_loading():
    clear_screen()
    console.print(Align.center(ASCII_ART))
    console.print(f"[dim]Рабочая папка: {BASE_DIR}[/dim]", justify="center")
    
    steps = ["Чтение конфигов...", "Проверка сессий...", "Оптимизация памяти...", "Запуск системы..."]
    
    with Progress(SpinnerColumn(style="bold green"), TextColumn("[bold white]{task.description}"), BarColumn(bar_width=30, style="dim green", complete_style="green"), console=console, transient=True) as p:
        task = p.add_task("Init", total=100)
        enable_swap()
        for step in steps:
            time.sleep(0.2)
            p.update(task, advance=25, description=step)

async def visual_sleep(seconds: int, text: str = "Ожидание"):
    if seconds <= 0: return
    with Progress(SpinnerColumn("dots", style="white"), TextColumn(f"[bold white]{text}..."), TimeRemainingColumn(), transient=True, console=console) as p:
        task = p.add_task("Wait", total=seconds)
        for _ in range(seconds): await asyncio.sleep(1); p.advance(task, 1)

def log_success(msg): console.print(f" [bold green]✔[/bold green] [white]{msg}[/white]")
def log_error(msg): console.print(f" [bold red]✖[/bold red] [white]{msg}[/white]")
def log_info(msg): console.print(f" [bold blue]ℹ[/bold blue] [dim white]{msg}[/dim white]")
def log_warn(msg): console.print(f" [bold yellow]⚠[/bold yellow] [yellow]{msg}[/yellow]")
def input_neon(label: str, password=False) -> str: return Prompt.ask(f"[bold cyan]➤ {label}[/bold cyan]", password=password)

# -------------------- УТИЛИТЫ --------------------

def normalize_phone(s: str) -> str: return ("+" + re.sub(r"\D", "", (s or "").strip())) if re.sub(r"\D", "", (s or "").strip()) else ""
def phone_to_session_name(phone: str) -> str: return re.sub(r"\D", "", phone) if re.sub(r"\D", "", phone) else "acc"
def safe_name(s: str) -> str: return re.sub(r"[^\dA-Za-z_-]", "_", (s or "").strip())

def _parse_env(text: str) -> dict: return {ln.split("=", 1)[0].strip(): ln.split("=", 1)[1].strip() for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#") and "=" in ln}

def _load_env_file() -> dict:
    if not ENV_FILE.exists(): return {}
    try: return _parse_env(ENV_FILE.read_text(encoding="utf-8"))
    except: return {}

def _save_env(api_id: str, api_hash: str) -> None: 
    ENV_FILE.write_text(f"TELEGRAM_API_ID={api_id}\nTELEGRAM_API_HASH={api_hash}\n", encoding="utf-8")

def get_api() -> Tuple[int, str]:
    fe = _load_env_file()
    api_id = os.environ.get("TELEGRAM_API_ID") or fe.get("TELEGRAM_API_ID")
    api_hash = os.environ.get("TELEGRAM_API_HASH") or fe.get("TELEGRAM_API_HASH")
    if api_id and api_hash:
        try: return int(api_id), api_hash
        except: pass
    
    console.print(Panel("[blink bold red]⚠ .ENV ФАЙЛ НЕ НАЙДЕН[/blink bold red]\nВведите ваши API ключи (они сохранятся локально)", border_style="red"))
    while True:
        api_id_in = input_neon("Введите API_ID")
        if api_id_in.isdigit(): break
    api_hash_in = input_neon("Введите API_HASH")
    if not api_hash_in: sys.exit(1)
    _save_env(api_id_in, api_hash_in)
    return int(api_id_in), api_hash_in

def session_path(session_name: str) -> Path: return SESSIONS / f"{safe_name(session_name)}.session"

def list_sessions() -> List[str]:
    if not SESSIONS.exists(): return []
    stems = [p.stem for p in SESSIONS.glob("*.session")]
    nums = [int(s) for s in stems if s.isdigit()]; others = [s for s in stems if not s.isdigit()]
    nums.sort(); others.sort()
    return [str(n) for n in nums] + others

def parse_selection(sessions: List[str]) -> List[str]:
    console.print("[dim]Введите ID сессий (пример: 1 3 5-10 15-20)[/dim]")
    raw = input_neon("Ваш выбор")
    if not raw: return []
    
    parts = re.split(r'[,\s]+', raw)
    selected_indices = set()
    
    for p in parts:
        if '-' in p:
            try:
                start_str, end_str = p.split('-')
                start, end = int(start_str), int(end_str)
                for i in range(min(start, end), max(start, end) + 1):
                    if 1 <= i <= len(sessions):
                        selected_indices.add(i)
            except ValueError:
                continue
        elif p.isdigit():
            idx = int(p)
            if 1 <= idx <= len(sessions):
                selected_indices.add(idx)
                
    final_list = [sessions[i-1] for i in sorted(list(selected_indices))]
    if not final_list: log_error("Выбор пуст")
    else: log_info(f"Выбрано аккаунтов: {len(final_list)}")
    return final_list

def client_for_session(session_name: str) -> TelegramClient:
    api_id, api_hash = get_api()
    import logging; logging.getLogger('telethon').setLevel(logging.CRITICAL)
    return TelegramClient(str(session_path(session_name)), api_id, api_hash)

def read_phones() -> List[str]:
    if not PHONES_FILE.exists(): 
        PHONES_FILE.touch()
        return []
    try: return list(dict.fromkeys([normalize_phone(ln) for ln in PHONES_FILE.read_text(encoding="utf-8").splitlines() if normalize_phone(ln)]))
    except: return []

async def is_session_authorized(session_name: str) -> bool:
    sp = session_path(session_name)
    if not sp.exists(): return False
    c = client_for_session(session_name)
    try:
        await c.connect()
        return await c.is_user_authorized()
    except: return False
    finally: await c.disconnect()

async def login_by_phone(phone: str, session_name: Optional[str] = None) -> bool:
    phone = normalize_phone(phone)
    if not phone: return False
    if not session_name: session_name = phone_to_session_name(phone)
    c = client_for_session(session_name)
    await c.connect()
    try:
        if await c.is_user_authorized(): log_success(f"Аккаунт уже активен: {phone}"); return True
        try: 
            await c.send_code_request(phone)
            log_info(f"Код отправлен на {phone}")
        except FloodWaitError as fw: log_error(f"Бан на {fw.seconds} сек."); return False
        except RPCError as e:
            if "ResendCodeRequest" in str(e) or "Returned when all available options" in str(e):
                log_error(f"Лимит попыток исчерпан для {phone}")
                return False
            log_error(f"Ошибка API: {e}"); return False
        except Exception as e: log_error(f"Ошибка: {e}"); return False
        
        code = input_neon("Введите код")
        try: await c.sign_in(phone, code); log_success(f"Успешный вход: {phone}"); return True
        except SessionPasswordNeededError:
            pw = input_neon("Введите пароль 2FA", password=True)
            try: await c.sign_in(password=pw); log_success("Вход выполнен (2FA)"); return True
            except: log_error("Неверный пароль 2FA"); return False
        except Exception: log_error("Неверный код подтверждения"); return False
    finally: await c.disconnect()

async def login_one():
    phone = normalize_phone(input_neon("Введите номер телефона"))
    if not phone: return
    ex = []
    for s in list_sessions():
        if s.isdigit(): ex.append(int(s))
    next_num = (max(ex) + 1) if ex else 1
    await login_by_phone(phone, str(next_num))

async def login_many():
    phones = read_phones()
    if not phones: log_error("Файл phones.txt пуст или не найден"); return
    
    table = Table(title="ОЧЕРЕДЬ НОМЕРОВ", box=box.SIMPLE, show_header=False)
    table.add_column("ID", style="cyan")
    table.add_column("Номер")
    for i, p in enumerate(phones, 1): table.add_row(str(i), p)
    console.print(table)
    
    if input_neon("Начать процесс входа? (y/n)") != "y": return
    ok = 0
    for i, p in enumerate(phones, 1):
        console.print(f"\n[bold magenta] ОБРАБОТКА АККАУНТА {i}: {p} [/bold magenta]")
        try:
            if await is_session_authorized(str(i)): 
                log_success("Сессия уже авторизована"); ok+=1; continue
            if await login_by_phone(p, str(i)): ok+=1
        except Exception as e: log_error(str(e))
    console.print(Panel(f"Итог массового входа: {ok}/{len(phones)} успешно"))

# -------------------- КОНВЕРТАЦИЯ В TDATA (ТИХИЙ АВТО-ПАРОЛЬ) --------------------

async def convert_worker(session_name: str):
    if not OPENTELE_AVAILABLE:
        log_error("Библиотека opentele не установлена! (pip install opentele)")
        return

    dest_folder = DATA_DIR / f"{session_name}tdata"
    if dest_folder.exists():
        try: shutil.rmtree(dest_folder)
        except:
            log_warn(f"Папка {dest_folder.name} уже существует. Пропуск.")
            return

    c = client_for_session(session_name)
    try:
        await c.connect()
        if not await c.is_user_authorized():
            log_error(f"[{session_name}] Сессия не авторизована.")
            return
        
        console.print(f"   [dim]Конвертация {session_name} в TData...[/dim]")
        
        tdesk = None
        try:
            # 1. Сначала пробуем просто так (без пароля)
            tdesk = await TDesktop.FromTelethon(c)
        except (NoPasswordProvided, SessionPasswordNeededError):
            # 2. Если нужен пароль, МОЛЧА пробуем стандартный
            try:
                tdesk = await TDesktop.FromTelethon(c, password=DEFAULT_2FA_PASS)
            except Exception:
                # 3. Если стандартный не подошел - только тогда пишем ошибку и спрашиваем
                console.print(f"   [red]✖ Пароль по умолчанию не подошел![/red]")
                pwd = input_neon("Введите пароль вручную", password=True)
                try:
                    tdesk = await TDesktop.FromTelethon(c, password=pwd)
                except Exception as e_final:
                    log_error(f"Ошибка ручного ввода: {e_final}")
                    return

        if tdesk:
            tdesk.SaveTData(dest_folder)
            log_success(f"[{session_name}] Сохранено в DATA/{session_name}tdata")
        
    except Exception as e:
        log_error(f"Критическая ошибка [{session_name}]: {e}")
    finally:
        await c.disconnect()

async def convert_menu():
    if not OPENTELE_AVAILABLE:
        console.print(Panel("[bold red]ОШИБКА: Библиотека opentele не найдена.[/bold red]\nУстановите её командой:\n[yellow]pip install opentele[/yellow]"))
        input_neon("Нажмите Enter")
        return

    sessions = list_sessions()
    if not sessions: log_error("Сессии не найдены"); return

    console.print("[1] Конвертировать ВСЕ\n[2] Выбрать аккаунты")
    scope = input_neon("Ваш выбор")
    targets = sessions if scope == "1" else parse_selection(sessions)
    if not targets: return

    for s in targets:
        await convert_worker(s)
    
    console.print(Panel("Конвертация завершена. Проверьте папку DATA.", style="green"))
    input_neon("Нажмите Enter")

# -------------------- СТАТИСТИКА --------------------

async def get_acc_stats(session_name: str) -> Tuple[int, int]:
    c = client_for_session(session_name)
    await c.connect()
    try:
        if not await c.is_user_authorized(): return (-1, -1)
        g = 0; ch = 0
        async for dialog in c.iter_dialogs(limit=None, ignore_migrated=True):
            if getattr(dialog.entity, 'creator', False):
                if dialog.is_group: g += 1
                elif dialog.is_channel: ch += 1
        return (g, ch)
    except: return (-1, -1)
    finally: await c.disconnect()

async def stats_menu():
    sessions = list_sessions()
    if not sessions: log_error("Сессии не найдены"); return

    console.print("[1] Проверить все\n[2] Выбрать конкретные")
    scope = input_neon("Ваш выбор")
    targets = sessions if scope == "1" else parse_selection(sessions)
    if not targets: return

    table = Table(title="СТАТИСТИКА ВЛАДЕНИЯ ЧАТАМИ", box=box.ROUNDED)
    table.add_column("Сессия")
    table.add_column("Группы", style="green")
    table.add_column("Каналы", style="magenta")

    total_groups = 0
    total_channels = 0

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), BarColumn(), console=console, transient=True) as p:
        task = p.add_task("Сканирование...", total=len(targets))
        for s in targets:
            g, ch = await get_acc_stats(s)
            if g == -1: 
                table.add_row(s, "Ошибка", "Ошибка")
            else: 
                table.add_row(s, str(g), str(ch))
                total_groups += g
                total_channels += ch
            p.advance(task, 1)

    table.add_section()
    table.add_row("[bold white]ИТОГО:[/bold white]", f"[bold green]{total_groups}[/bold green]", f"[bold magenta]{total_channels}[/bold magenta]")

    console.print(table)
    console.print(Panel(f"Суммарно по всем аккаунтам:\n[bold green]Групп: {total_groups}[/bold green]\n[bold magenta]Каналов: {total_channels}[/bold magenta]", title="РЕЗУЛЬТАТ", border_style="cyan"))
    input_neon("Нажмите Enter")

# -------------------- РАССЫЛКА --------------------

async def broadcast_worker(session_name: str, text: str):
    c = client_for_session(session_name)
    await c.connect()
    try:
        if not await c.is_user_authorized(): return
        sent = 0
        async for dialog in c.iter_dialogs(limit=None, ignore_migrated=True):
            if getattr(dialog.entity, 'creator', False):
                try:
                    await c.send_message(dialog.entity, text)
                    sent += 1
                    console.print(f"   [green]➜ Отправлено в:[/green] {dialog.name[:20]}")
                    await asyncio.sleep(random.uniform(0.3, 0.7)) 
                except FloodWaitError as e: await asyncio.sleep(e.seconds)
                except: pass
        log_success(f"[{session_name}] Итого разослано: {sent}")
    finally: await c.disconnect()

async def broadcast_menu():
    sessions = list_sessions()
    if not sessions: log_error("Сессии не найдены"); return
    
    console.print("[1] Рассылка по всем\n[2] Выбрать аккаунты")
    scope = input_neon("Ваш выбор")
    targets = sessions if scope == "1" else parse_selection(sessions)
    if not targets: return

    msg = input_neon("Введите текст сообщения")
    if not msg: return

    for s in targets:
        console.print(f"[bold magenta]Аккаунт: {s}[/bold magenta]")
        await broadcast_worker(s, msg)
        await visual_sleep(ACCOUNT_COOLDOWN, "Смена аккаунта")

# -------------------- СОРТИРОВКА --------------------

async def safe_get_input_entity(c, entity):
    try: return await c.get_input_entity(entity)
    except FloodWaitError as e: await asyncio.sleep(e.seconds); return await safe_get_input_entity(c, entity)
    except: return None

async def sort_owner_chats(session_name: str):
    c = client_for_session(session_name)
    await c.connect()
    try:
        if not await c.is_user_authorized(): return
        
        my_groups, my_channels = [], []
        async for dialog in c.iter_dialogs(limit=None, ignore_migrated=True):
            if dialog.is_user: continue
            ent = dialog.entity
            if getattr(ent, 'creator', False):
                inp = await safe_get_input_entity(c, ent)
                if inp:
                    if getattr(ent, 'broadcast', False): my_channels.append(inp)
                    else: my_groups.append(inp)

        for fid in [115, 116]:
            try: await c(UpdateDialogFilterRequest(id=fid, filter=None))
            except: pass

        if my_groups:
            await c(UpdateDialogFilterRequest(id=115, filter=DialogFilter(id=115, title=TextWithEntities("Группы", []), emoticon="👥", pinned_peers=[], include_peers=my_groups[:100], exclude_peers=[], contacts=False, non_contacts=False, groups=False, broadcasts=False, bots=False, exclude_muted=False, exclude_read=False, exclude_archived=False)))
        
        if my_channels:
            await c(UpdateDialogFilterRequest(id=116, filter=DialogFilter(id=116, title=TextWithEntities("Каналы", []), emoticon="📢", pinned_peers=[], include_peers=my_channels[:100], exclude_peers=[], contacts=False, non_contacts=False, groups=False, broadcasts=False, bots=False, exclude_muted=False, exclude_read=False, exclude_archived=False)))

        all_peers = my_groups + my_channels
        if all_peers:
            log_info(f"Архивация {len(all_peers)} чатов...")
            for i in range(0, len(all_peers), ARCHIVE_CHUNK_SIZE):
                chunk = all_peers[i:i + ARCHIVE_CHUNK_SIZE]
                try:
                    await c(EditPeerFoldersRequest(folder_peers=[InputFolderPeer(p, 1) for p in chunk]))
                    await asyncio.sleep(2)
                except FloodWaitError as e: await asyncio.sleep(e.seconds + 2)
                except: pass
            log_success(f"Аккаунт {session_name} отсортирован")
            
    finally: await c.disconnect()

async def sort_menu():
    sessions = list_sessions()
    if not sessions: log_error("Сессии не найдены"); return
    console.print("[1] Сортировать все\n[2] Выбрать аккаунты")
    scope = input_neon("Ваш выбор")
    targets = sessions if scope == "1" else parse_selection(sessions)
    if not targets: return
    
    for s in targets:
        console.print(f"Сортировка на аккаунте: {s}")
        await sort_owner_chats(s)
    input_neon("Нажмите Enter")

# -------------------- ВОРКЕР --------------------

async def create_worker(session_name: str, count: int, is_channel: bool):
    c = client_for_session(session_name)
    await c.connect()
    try:
        if not await c.is_user_authorized(): return
        for i in range(count):
            try:
                res = await c(CreateChannelRequest(title="1" if not is_channel else "2", about="", megagroup=not is_channel))
                chat = res.chats[0]
                await visual_sleep(3, "Инициализация в Telegram")
                if not is_channel:
                    try: await c(TogglePreHistoryHiddenRequest(channel=chat, enabled=False))
                    except: pass
                try: await c.send_message(chat, "привет")
                except: pass
                log_success(f"Создано ({i+1}/{count})")
                await visual_sleep(COOLDOWN, "Кулдаун")
            except FloodWaitError as e:
                log_warn(f"Лимит на {session_name}: ждем {e.seconds} с. ПЕРЕХОД...")
                return 
            except Exception as e: 
                log_error(f"Ошибка: {str(e)}")
                if "too many" in str(e).lower(): return 
    finally: await c.disconnect()

async def worker_menu():
    sessions = list_sessions()
    if not sessions: log_error("Сессии не найдены"); return
    console.print("[1] Все аккаунты\n[2] Выбор аккаунтов")
    scope = input_neon("Ваш выбор")
    targets = sessions if scope == "1" else parse_selection(sessions)
    if not targets: return
    
    console.print("[1] Группы\n[2] Каналы")
    mode = input_neon("Тип")
    cnt = int(input_neon("Кол-во на аккаунт"))
    
    for s in targets:
        console.print(f"Воркер на аккаунте: {s}")
        await create_worker(s, cnt, is_channel=(mode=="2"))
        await visual_sleep(ACCOUNT_COOLDOWN, "Смена аккаунта")

# -------------------- ВЫХОД ИЗ ВСЕХ --------------------

async def logout_worker(session_name: str):
    c = client_for_session(session_name)
    sp = session_path(session_name)
    try:
        await c.connect()
        if await c.is_user_authorized():
            await c(LogOutRequest())
            log_success(f"[{session_name}] Сессия завершена в Telegram.")
        else:
            log_warn(f"[{session_name}] Сессия уже невалидна.")
    except Exception as e:
        log_error(f"[{session_name}] Ошибка при выходе: {e}")
    finally:
        await c.disconnect()
        if sp.exists():
            try:
                sp.unlink()
                log_info(f"Файл {sp.name} удален.")
            except:
                log_error(f"Не удалось удалить файл {sp.name}")

async def logout_menu():
    sessions = list_sessions()
    if not sessions: log_error("Сессии не найдены"); return
    
    console.print(Panel("[bold red]ВНИМАНИЕ: Это действие завершит сессии в TG и УДАЛИТ файлы![/bold red]"))
    console.print("[1] Выйти из ВСЕХ\n[2] Выбрать аккаунты")
    scope = input_neon("Ваш выбор")
    targets = sessions if scope == "1" else parse_selection(sessions)
    if not targets: return

    confirm = input_neon(f"Вы уверены, что хотите выйти из {len(targets)} акк.? (y/n)")
    if confirm.lower() != 'y': return

    for s in targets:
        await logout_worker(s)
    
    log_success("Процесс завершен.")
    input_neon("Нажмите Enter")

# -------------------- ГЛАВНОЕ МЕНЮ --------------------

def show_menu():
    clear_screen()
    console.print(Align.center(ASCII_ART))
    
    total_sessions = len(list_sessions())
    stats = f"Активных сессий: [cyan]{total_sessions}[/cyan] | Путь: [dim]{SESSIONS}[/dim]"
    
    menu = Table(box=box.SIMPLE, show_header=False)
    menu.add_row("[1] Авто-вход", "[dim]из phones.txt[/dim]")
    menu.add_row("[2] Ручной вход", "[dim]ввод номера[/dim]")
    menu.add_row("[3] Воркер", "[dim]создание Г/К[/dim]")
    menu.add_row("[4] Список сессий", "[dim]просмотр имён[/dim]")
    menu.add_row("[5] Статистика", "[dim]владение чатами[/dim]")
    menu.add_row("[6] Рассылка", "[dim]по своим чатам[/dim]")
    menu.add_row("[7] Сортировка", "[dim]папки и архив[/dim]")
    menu.add_row("[8] Logout", "[bold red]выйти из всех[/bold red]")
    menu.add_row("", "")
    menu.add_row("[9] Конвертация в TData", "[dim]создание папки[/dim]")
    menu.add_row("", "")
    menu.add_row("[0] Выход", "")
    
    console.print(Panel(stats, style="white on black"))
    console.print(Panel(menu, title="ГЛАВНОЕ МЕНЮ", border_style="green"))

async def main():
    fake_loading()
    try: _ = get_api()
    except SystemExit: return
    
    while True:
        show_menu()
        ch = Prompt.ask("[bold green]ВЫБЕРИТЕ ПУНКТ[/bold green]", choices=["1","2","3","4","5","6","7","8","9","0"])
        if ch == "1": await login_many(); input_neon("Нажмите Enter")
        elif ch == "2": await login_one(); input_neon("Нажмите Enter")
        elif ch == "3": await worker_menu(); input_neon("Нажмите Enter")
        elif ch == "4": 
            sess_list = list_sessions()
            if sess_list: console.print(f"Сессии: [bold cyan]{', '.join(sess_list)}[/bold cyan]")
            else: log_info("Папка сессий пуста")
            input_neon("Нажмите Enter")
        elif ch == "5": await stats_menu()
        elif ch == "6": await broadcast_menu(); input_neon("Нажмите Enter")
        elif ch == "7": await sort_menu()
        elif ch == "8": await logout_menu()
        elif ch == "9": await convert_menu()
        elif ch == "0": sys.exit(0)

if __name__ == "__main__":
    try: asyncio.run(main())
    except KeyboardInterrupt: 
        console.print("\n[bold red]Работа программы прервана пользователем.[/bold red]")